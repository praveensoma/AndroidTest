package com.ashley.ashley;

import static com.ashley.ashley.utils.Config.CLIENT_MODE;
import static java.lang.Math.PI;
import static java.lang.Math.abs;
import static java.lang.Math.asin;
import static java.lang.Math.atan2;
import static java.lang.Math.cos;
import static java.lang.Math.round;
import static java.lang.Math.sin;
import static java.lang.Math.sqrt;
import static java.lang.Math.toDegrees;
import static java.lang.Math.toRadians;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.ashley.ashley.extra.ExtraFunctions;
import com.ashley.ashley.filewriting.DataFileWriter;
import com.ashley.ashley.net.ChatServer;
import com.ashley.ashley.sensor.gyroscope.ComplementaryGyroscopeSensor;
import com.ashley.ashley.sensor.gyroscope.KalmanGyroscopeSensor;
import com.ashley.ashley.stepcounting.StaticStepCounter;
import com.ashley.ashley.utils.JmDNSHelper;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import de.proglove.sdk.ConnectionStatus;
import de.proglove.sdk.IPgManager;
import de.proglove.sdk.IServiceOutput;
import de.proglove.sdk.PgError;
import de.proglove.sdk.PgManager;
import de.proglove.sdk.button.BlockPgTriggersParams;
import de.proglove.sdk.button.ButtonPress;
import de.proglove.sdk.button.IBlockPgTriggersCallback;
import de.proglove.sdk.button.IButtonOutput;
import de.proglove.sdk.button.IPgTriggersUnblockedOutput;
import de.proglove.sdk.button.PredefinedPgTrigger;
import de.proglove.sdk.commands.PgCommand;
import de.proglove.sdk.commands.PgCommandParams;
import de.proglove.sdk.configuration.IPgGetConfigProfilesCallback;
import de.proglove.sdk.configuration.IPgScannerConfigurationChangeOutput;
import de.proglove.sdk.configuration.PgConfigProfile;
import de.proglove.sdk.configuration.PgScannerConfigurationChangeResult;
import de.proglove.sdk.configuration.ScannerConfigurationChangeStatus;
import de.proglove.sdk.display.IDisplayOutput;
import de.proglove.sdk.display.IPgSetScreenCallback;
import de.proglove.sdk.display.PgScreenData;
import de.proglove.sdk.display.PgTemplateField;
import de.proglove.sdk.display.RefreshType;
import de.proglove.sdk.scanner.BarcodeScanResults;
import de.proglove.sdk.scanner.DeviceVisibilityInfo;
import de.proglove.sdk.scanner.IPgDeviceVisibilityCallback;
import de.proglove.sdk.scanner.IPgFeedbackCallback;
import de.proglove.sdk.scanner.IPgImageCallback;
import de.proglove.sdk.scanner.IScannerOutput;
import de.proglove.sdk.scanner.ImageResolution;
import de.proglove.sdk.scanner.PgImage;
import de.proglove.sdk.scanner.PgImageConfig;
import de.proglove.sdk.scanner.PgPredefinedFeedback;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;



class FloatPoint {
    float x, y;

    public FloatPoint(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }
}


public class HelixForegroundService extends Service implements  SensorEventListener,
        IServiceOutput, IScannerOutput, IButtonOutput,
        IPgTriggersUnblockedOutput, IDisplayOutput, IPgScannerConfigurationChangeOutput
         {


    final Handler handler = new Handler();
    private static final String FILE_NAME = "myVariables.json";
    private Runnable runnable;
   private String uri = "http://helixsockets.dev.ashleyfurniture.com";
    public static final String CHANNEL_ID = "HelixForegroundServiceChannel";
    private static final String ACTION_STOP_SERVICE = "STOP";
    private final IBinder mBinder = new LocalService();

    private BroadcastReceiver broadcastReceiver;
    //webscocket Client
    private WebSocketClient mWebSocketClient;
    private Socket mSocketIOClient;
    private int stepCount = 0;
    private SensorManager SensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    private Sensor magnetometer;
    private float[] magnetometer1;
    private Sensor sensorLinearAcceleration;
    private static final String TAG = "HelixForegroundService";
    private float prevXVal = (float) 35.96219069;
    private float prevYVal = (float) -80.46881300;

    private float x_val = prevXVal;
    private float y_val = prevYVal;
    private float prevDist = 0;
    private float stepFactor = 0.5F;
    private float degree = 0;
    String degreeSelected = "rawdegree";
    private JSONObject message = new JSONObject("{\"x_Val\": \"" + x_val + "\",\"y_Val\": \"" + y_val + "\",\"degree\": \"0\",\"rawDegree\": \"0\",\"compDegree\": \"0\",\"kalmanDegree\": \"0\",\"stepCount\": \"0\"}");
    private boolean CameraRunning = false;
    private boolean captureImageRunning = false;

    private boolean webSocketCalled = false;
    private List<Sensor> msensorList;
    private int defaultImageQuality;
    private static int DEFAULT_IMAGE_TIMEOUT = 10000;
    private String dString = "";
    private JSONObject progloveJson = new JSONObject("{\"ServiceStatus\": \"" + false + "\",\"ScannerStatus\": \"" + false + "\",\"scannerResult\": \"" + dString + "\",\"resultSymbology\": \"" + dString + "\",\"DisplayStatus\": \"" + false + "\"}");

    private int pgBatteryLevel;
    private String pgSerial;
    private String pgFirmware;
    private String pgModel;

    private boolean started_ = false;
    private boolean SocketConnected = false;
    FusedLocationProviderClient mFusedLocationClient;
    private boolean webSocketServerRunning = false;
    private boolean allPermissionsGranted=false;


    public HelixForegroundService() throws JSONException {
    }

    public static FloatPoint movePoint(double latitude, double longitude, double distanceInMetres, double bearing) {
        double brngRad = toRadians(bearing);
        double latRad = toRadians(latitude);
        double lonRad = toRadians(longitude);
        int earthRadiusInMetres = 6371000;
        double distFrac = distanceInMetres / earthRadiusInMetres;

        double latitudeResult = asin(sin(latRad) * cos(distFrac) + cos(latRad) * sin(distFrac) * cos(brngRad));
        double a = atan2(sin(brngRad) * sin(distFrac) * cos(latRad), cos(distFrac) - sin(latRad) * sin(latitudeResult));
        double longitudeResult = (lonRad + a + 3 * PI) % (2 * PI) - PI;
        return new FloatPoint((float) toDegrees(latitudeResult), (float) toDegrees(longitudeResult));
//        System.out.println("latitude: " + toDegrees(latitudeResult) + ", longitude: " + toDegrees(longitudeResult));
    }

    ComplementaryGyroscopeSensor complementaryGyroscopeSensor;
    KalmanGyroscopeSensor kalmanGyroscopeSensor;
    private static StaticStepCounter[] staticStepCounters;
    private DataFileWriter dataFileWriter;
    private static final String FOLDER_NAME = "INS/Testing";
    private static final String[] DATA_FILE_NAMES = {
            "Path"
    };
    private static final String[] DATA_FILE_HEADINGS = {
            "Path" + "\n" + "t;Ax;Ay;Az"
    };


    private Socket mSocket;

    {

        try {
            mSocket = IO.socket(uri);
        } catch (URISyntaxException e) {
            sendStringTowebSocket("Could not connect to " + uri);
        }
    }


    private final Logger logger = Logger.getLogger(TAG);
    private final IPgManager pgManager = new PgManager(logger, Executors.newCachedThreadPool());

    //websocketServerCode started
    private JmDNSHelper jmDNSHelper;
    private ChatServer server = new ChatServer(8080);
    //webSocketServerCode stopped
    private Intent notificationIntent;

    @Override
    public void onCreate() {
        super.onCreate();



        //websocketServerCode started
        server.setReuseAddr(true);
        server.start();
        initJmDNSHelper();
        registerNSD();
        //webSocketServerCode stopped


        mSocket.on(Socket.EVENT_CONNECT, onConnect);
        mSocket.on(Socket.EVENT_DISCONNECT, onDisconnect);
        mSocket.on(Socket.EVENT_CONNECT_ERROR, onConnectError);
        mSocket.on("iot-voice", onNewMessage);
        mSocket.connect();



        registerReceiver();
        registerReceiver(networkStateReceiver, new IntentFilter(android.net.ConnectivityManager.CONNECTIVITY_ACTION));

        runnable = new Runnable() {
            @Override
            public void run() {
                // Do the task...
                handler.postDelayed(this, 3000); // Optional, to repeat the task
                if(mWebSocketClient==null){
                    connectWebSocket();
                }
                if(mWebSocketClient!=null && mWebSocketClient.isOpen()) {
                    if(allPermissionsGranted) {

                        handler.removeCallbacks(this);
                    }
                }else{
                    connectWebSocket();
                }
            }
        };
        handler.postDelayed(runnable, 3000);


        Log.d(TAG, "onCreate: Initialising Sensor Services");
        SensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        msensorList = SensorManager.getSensorList(Sensor.TYPE_ALL);
        sensorLinearAcceleration = SensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);


        accelerometer = SensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        if (accelerometer != null) {
            SensorManager.registerListener((SensorEventListener) HelixForegroundService.this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
            Log.d(TAG, "onCreate: Registered Accelerometer Listner");
        } else {
//            xValue.setText("No Sensor Found");
        }

        gyroscope = SensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if (gyroscope != null) {
            SensorManager.registerListener((SensorEventListener) HelixForegroundService.this, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
            Log.d(TAG, "onCreate: Registered Gyroscope Listner");
        } else {
//            Gyrox.setText("No Sensor Found");
        }

        magnetometer = SensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (magnetometer != null) {
            SensorManager.registerListener((SensorEventListener) HelixForegroundService.this, magnetometer, SensorManager.SENSOR_DELAY_NORMAL);
            Log.d(TAG, "onCreate: Registered Magnetometer Listner");
        } else {
//            Magnx.setText("No Sensor Found");
        }


        complementaryGyroscopeSensor = new ComplementaryGyroscopeSensor(this.getApplicationContext());

        complementaryGyroscopeSensor.start();

        kalmanGyroscopeSensor = new KalmanGyroscopeSensor(this.getApplicationContext());
        kalmanGyroscopeSensor.start();

        //linear path  //previously defining step counter
        staticStepCounters = new StaticStepCounter[5];
        staticStepCounters[0] = new StaticStepCounter(0.9, 0.3); // 2,1.9
        staticStepCounters[1] = new StaticStepCounter(1.9, 1.5); // 3, 2.9
        staticStepCounters[2] = new StaticStepCounter(2.6, 2.0); // 4,3.9
        staticStepCounters[3] = new StaticStepCounter(3, 2.5); //5,4.9
        staticStepCounters[4] = new StaticStepCounter(3.6, 3.2); //6,5,9

        for (StaticStepCounter staticStepCounter : staticStepCounters) {
            staticStepCounter.clearStepCount();
        }

        try {
            pgManager.subscribeToServiceEvents(this);
            pgManager.subscribeToScans(this);
            pgManager.subscribeToButtonPresses(this);
            pgManager.subscribeToPgTriggersUnblocked(this);
            pgManager.subscribeToPgScannerConfigurationChanges(this);

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    private boolean checkPermissions() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;

        // If we want background location
        // on Android 10.0 and higher,
        // use:
        // ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    @SuppressLint("MissingPermission")
    private void requestNewLocationData() {

        // Initializing LocationRequest
        // object with appropriate methods
        LocationRequest mLocationRequest = LocationRequest.create()
                .setInterval(5)
                .setFastestInterval(0)
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setMaxWaitTime(1);


        // setting LocationRequest
        // on FusedLocationClient
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, android.os.Looper.myLooper());
    }

    private LocationCallback mLocationCallback = new LocationCallback() {

        @Override
        public void onLocationResult(LocationResult locationResult) {
            Location mLastLocation = locationResult.getLastLocation();
            //Send via web sockets
            JSONObject locationObject = new JSONObject();
            try {
                locationObject.put("topic", "GPS Data");
                locationObject.put("latitude", mLastLocation.getLatitude());
                locationObject.put("longitude", mLastLocation.getLongitude());
                sendToWebSocket(locationObject);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    };

    @SuppressLint("MissingPermission")
    private void getLastLocation() {
        // check if permissions are given
        mFusedLocationClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
            @Override
            public void onComplete(@NonNull Task<Location> task) {
                Location location = task.getResult();
                if (location == null) {

                } else {
                    //Send via web sockets
                    JSONObject locationObject = new JSONObject();
                    try {
                        locationObject.put("topic", "GPS Data");

                        locationObject.put("latitude", location.getLatitude());
                        locationObject.put("longitude", location.getLongitude());
                        sendToWebSocket(locationObject);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    requestNewLocationData();
                }
            }
        });

    }

    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            String androidId = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ANDROID_ID);
            SocketConnected = true;
            mSocket.emit("join", androidId);
            sendStringTowebSocket("Successfully Connected to " + uri);
            getDeviceSuperInfo();
        }
    };

    private Emitter.Listener onDisconnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            SocketConnected = false;
            sendStringTowebSocket("Socket Disconnected from " + uri);
        }
    };

    private Emitter.Listener onConnectError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {

            SocketConnected = false;
            sendStringTowebSocket("Error Connecting to " + uri);
        }
    };
    private Emitter.Listener onNewMessage = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
//            JSONObject data = (JSONObject) args[0];
            Log.d("TAG", String.valueOf(args[0]));
            doOnMessage(String.valueOf(args[0]));
        }
    };




    private void registerReceiver() {
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String myMsg = intent.getStringExtra("com.ashley.ashley.QRCODE");
                if (myMsg != null) {
                    Log.d("TAG", "QRCODE Received");
                    try {
                        JSONObject myjsonObj = new JSONObject(myMsg);
                        sendToWebSocket(myjsonObj);
                        CameraRunning = false;
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                String camMsg = intent.getStringExtra("com.ashley.ashley.CAMERA");
                if (camMsg != null) {
                    Log.d("TAG", "Capture Image Received");
                    try {
                        JSONObject myjsonObj = new JSONObject(camMsg);
                        sendToWebSocket(myjsonObj);
                        captureImageRunning = false;
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                String ioioMsg = intent.getStringExtra("com.ashley.ashley.IOIO");

                if (ioioMsg != null) {
                    Log.d("TAG", "IOIO Data Received");
                    try {
                        JSONObject myjsonObj = new JSONObject(ioioMsg);
                        sendToWebSocket(myjsonObj);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        };
        registerReceiver(broadcastReceiver, new IntentFilter("com.ashley.ashley"));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        String input = intent.getStringExtra("inputExtra");
        createNotificationChannel();
        
        if(input!=null) {
            if (input.contains("Main")) {
                notificationIntent = new Intent(this, MainActivity.class);
            } else {
                notificationIntent = new Intent(this, UserMainActivity.class);
            }
        }

        notificationIntent.putExtra("Notification", "True");

            PendingIntent pendingIntent = PendingIntent.getActivity(this,
                    0, notificationIntent, 0);


            if (ACTION_STOP_SERVICE.equals(intent.getAction())) {
                Intent in = new Intent("com.ashley.ashley");
                Bundle extras = new Bundle();
                extras.putString("com.ashley.ashley.COMM", "KILL");
                in.putExtras(extras);
                sendBroadcast(in);
                Log.d("TAG", "called to cancel service");
                stopSelf();
            }
            Intent stopSelf = new Intent(this, HelixForegroundService.class);
            stopSelf.setAction(ACTION_STOP_SERVICE);


            PendingIntent pStopSelf = PendingIntent
                    .getService(this, 0, stopSelf
                            , PendingIntent.FLAG_CANCEL_CURRENT);  // That you should change this part in your code


            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("Helix Android Thing")
                    .setContentText(input)
                    .setSmallIcon(R.drawable.ashley)
                    .setContentIntent(pendingIntent)
                    .addAction(android.R.drawable.ic_delete, "EXIT", pStopSelf)
                    .setOngoing(true)
                    .build();


            startForeground(1, notification);
        //do heavy work on a background thread
        //stopSelf();
        return START_REDELIVER_INTENT;
    }


//datafile started
    public void setVariable(String variableName, String variableValue){
    JSONObject jsonObject = new JSONObject();
    try {
        jsonObject = new JSONObject(readFromFile());
    } catch (JSONException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }
    try {
        jsonObject.put(variableName, variableValue);
    } catch (JSONException e) {
        e.printStackTrace();
    }

    try {
        writeToFile(jsonObject);
    } catch (IOException e) {
        e.printStackTrace();
    }
}
    public String getVariable(String variableName){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject = new JSONObject(readFromFile());
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String variableValue=null;
        try {
            variableValue=jsonObject.get(variableName).toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return variableValue;
    }

    public void writeToFile(JSONObject JsonObject) throws IOException {
        // Convert JsonObject to String Format
        String userString = JsonObject.toString();
// Define the File Path and its Name
        File file = new File(this.getApplicationContext().getFilesDir(),FILE_NAME);
        FileWriter fileWriter = new FileWriter(file);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        bufferedWriter.write(userString);
        bufferedWriter.close();
    }
    public String readFromFile() throws IOException {
        File file = new File(this.getApplicationContext().getFilesDir(),FILE_NAME);
        FileReader fileReader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        StringBuilder stringBuilder = new StringBuilder();
        String line = bufferedReader.readLine();
        while (line != null){
            stringBuilder.append(line).append("\n");
            line = bufferedReader.readLine();
        }
        bufferedReader.close();
// This responce will have Json Format String
        String responce = stringBuilder.toString();
        return responce;
    }

    //datafile ended


    private void getDeviceSuperInfo() {
        Log.i(TAG, "getDeviceSuperInfo");
        try {
            JSONObject S = new JSONObject("{\"text\":\"text\",\"topic\":\"deviceInfo\"}");
            JSONObject text = new JSONObject();
            JSONObject deviceInfo = new JSONObject();
            deviceInfo.put("OS Version", System.getProperty("os.version") + "(" + android.os.Build.VERSION.INCREMENTAL + ")");
            deviceInfo.put("OS API Level", android.os.Build.VERSION.SDK_INT);
            deviceInfo.put("Device", android.os.Build.DEVICE);
            deviceInfo.put("Model", android.os.Build.MODEL + " (" + android.os.Build.PRODUCT + ")");
            deviceInfo.put("RELEASE", android.os.Build.VERSION.RELEASE);
            deviceInfo.put("BRAND", android.os.Build.BRAND);
            deviceInfo.put("HARDWARE", android.os.Build.HARDWARE);
            deviceInfo.put("Build_ID", android.os.Build.ID);
            deviceInfo.put("MANUFACTURER", android.os.Build.MANUFACTURER);

            text.put("deviceInfo", deviceInfo);

            WifiManager mWiFiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
            WifiInfo w = mWiFiManager.getConnectionInfo();
            JSONObject wifiInfo = new JSONObject();
            wifiInfo.put("SSID", w.getSSID());
            wifiInfo.put("Frequency", w.getFrequency());
            wifiInfo.put("LinkSpeed", w.getLinkSpeed());
            wifiInfo.put("RSSI", w.getRssi());
            wifiInfo.put("IPAddress", w.getIpAddress());
            wifiInfo.put("NetId", w.getNetworkId());
            S.put("wifiInfo", wifiInfo);
            JSONObject sensorInfo = new JSONObject();
            for (int i = 0; i < msensorList.size(); i++) {
                sensorInfo.put("Sensor-" + i, msensorList.get(i).getName().toString());
            }
            text.put("SensorInfo", sensorInfo);
            Intent batteryStatus = getApplicationContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            final int batteryPercentage = (level * 100) / scale;

            int health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
            String batteryHealth;
            switch (health) {
                case BatteryManager.BATTERY_HEALTH_COLD:
                    batteryHealth = "COLD";
                    break;
                case BatteryManager.BATTERY_HEALTH_DEAD:
                    batteryHealth = "DEAD";
                    break;
                case BatteryManager.BATTERY_HEALTH_GOOD:
                    batteryHealth = "GOOD";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                    batteryHealth = "OVERHEAT";
                    break;
                case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                    batteryHealth = "OVER_VOLTAGE";
                    break;
                case BatteryManager.BATTERY_HEALTH_UNKNOWN:
                    batteryHealth = "UNKNOWN";
                    break;
                case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                    batteryHealth = "UNSPECIFIED_FAILURE";
                    break;
                default:
                    batteryHealth = Integer.toString(health);
            }

            // BatteryManager.EXTRA_PLUGGED: "Extra for ACTION_BATTERY_CHANGED: integer indicating whether the
            // device is plugged in to a power source; 0 means it is on battery, other constants are different types
            // of power sources."
            int pluggedInt = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
            String batteryPlugged;
            switch (pluggedInt) {
                case 0:
                    batteryPlugged = "UNPLUGGED";
                    break;
                case BatteryManager.BATTERY_PLUGGED_AC:
                    batteryPlugged = "PLUGGED_AC";
                    break;
                case BatteryManager.BATTERY_PLUGGED_USB:
                    batteryPlugged = "PLUGGED_USB";
                    break;
                case BatteryManager.BATTERY_PLUGGED_WIRELESS:
                    batteryPlugged = "PLUGGED_WIRELESS";
                    break;
                default:
                    batteryPlugged = "PLUGGED_" + pluggedInt;
            }

            double batteryTemperature = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) / 10.f;

            String batteryStatusString;
            int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            switch (status) {
                case BatteryManager.BATTERY_STATUS_CHARGING:
                    batteryStatusString = "CHARGING";
                    break;
                case BatteryManager.BATTERY_STATUS_DISCHARGING:
                    batteryStatusString = "DISCHARGING";
                    break;
                case BatteryManager.BATTERY_STATUS_FULL:
                    batteryStatusString = "FULL";
                    break;
                case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                    batteryStatusString = "NOT_CHARGING";
                    break;
                case BatteryManager.BATTERY_STATUS_UNKNOWN:
                    batteryStatusString = "UNKNOWN";
                    break;
                default:
                    batteryStatusString = "UNKNOWN";
            }

            BatteryManager batteryManager = (BatteryManager) getApplicationContext().getSystemService(Context.BATTERY_SERVICE);
            JSONObject batteryInfo = new JSONObject();
            for (int i = 0; i < msensorList.size(); i++) {
                sensorInfo.put("Sensor-" + i, msensorList.get(i).getName().toString());
            }

            batteryInfo.put("health", batteryHealth);
            batteryInfo.put("percentage", batteryPercentage);
            batteryInfo.put("plugged", batteryPlugged);
            batteryInfo.put("status", batteryStatusString);
            batteryInfo.put("temperature", batteryTemperature);
            batteryInfo.put("current", batteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW));
            text.put("batteryInfo", batteryInfo);
            S.put("text", text);

            Log.i(TAG + " | Device Info > ", S.toString());
            sendToWebSocket(S);
        } catch (Exception e) {
            Log.e(TAG, "Error getting Device INFO");
        }
    }//end getDeviceSuperInfo

    float[] mGravity;
    float[] mGeomagnetic;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onSensorChanged(SensorEvent SensorEvent) {
        Sensor Sensor = SensorEvent.sensor;
        Object sensors_event_t;

        float x_accel = 0.0f;
        float y_accel = 0.0f;
        float z_accel = 0.0f;

        if (Sensor.getType() == Sensor.TYPE_ACCELEROMETER) {

//            Log.d(TAG, " Accel-X: " + SensorEvent.values[0] + " Y:" + SensorEvent.values[1] + " Z:" + SensorEvent.values[2]);
//

            //Stepcount
            x_accel = SensorEvent.values[0];
            y_accel = SensorEvent.values[1];
            z_accel = SensorEvent.values[2];

            double Magnitude = sqrt(x_accel * x_accel + y_accel * y_accel + z_accel * z_accel);


//            double MagnitudeDelta = Magnitude - MagnitudePrevious;
//            MagnitudePrevious = Magnitude;


        } else if (Sensor.getType() == Sensor.TYPE_GYROSCOPE) {


        } else if (Sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {

        } else if (Sensor.getType() == Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR) {

        } else if (Sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION) {

            final double norm = ExtraFunctions.calcNorm(
                    SensorEvent.values[0] +
                            SensorEvent.values[1] +
                            SensorEvent.values[2]
            );

            for (StaticStepCounter staticStepCounter : staticStepCounters)
                staticStepCounter.findStep(norm);

            stepCount = staticStepCounters[0].getStepCount();

//            Log.d(TAG, "1145 stepcount is " + stepCount);


        }
        if (SensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
            mGravity = SensorEvent.values;
        if (SensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
            mGeomagnetic = SensorEvent.values;
        if (mGravity != null && mGeomagnetic != null) {
            float R[] = new float[9];
            float I[] = new float[9];
            boolean success = SensorManager.getRotationMatrix(R, I, mGravity, mGeomagnetic);
            if (success) {
                float orientation[] = new float[3];
                SensorManager.getOrientation(R, orientation);
                float azimut = orientation[0]; // orientation contains: azimut, pitch and roll
                float rawdegree = (float) (toDegrees(azimut) + 360) % 360;
                double distance = stepCount;

                if (abs((float) distance - prevDist) > 2) {

                    float compdegree = complementaryGyroscopeSensor.returnCompDegree();
                    float kalmandegree = kalmanGyroscopeSensor.returnKalmanDegree();


                    if (degreeSelected.equals("rawdegree")) {
                        degree = rawdegree;
                    }
                    if (degreeSelected.equals("compdegree")) {
                        degree = compdegree;
                    }
                    if (degreeSelected.equals("kalmandegree")) {
                        degree = kalmandegree;
                    }
                    //geodesic co-ordinates started
                    FloatPoint geo = movePoint(prevXVal, prevYVal, (distance - prevDist) * stepFactor, degree);
                    x_val = geo.x;
                    y_val = geo.y;
                    //geodesic co-ordinates ended

                    long time = System.currentTimeMillis();
//                            float compdegree = complementaryGyroscopeSensor.returnCompDegree();
                    String msg = "{\"x_Val\": \"" + (float) (round(x_val * 1000000.0) / 1000000.0) + "\",\"y_Val\": \"" + (float) (round(y_val * 1000000.0) / 1000000.0) + "\",\"degree\": \"" + (float) (round(degree * 100.0) / 100.0) + "\",\"compdegree\": \"" + (float) (compdegree) + "\",\"kalmandegree\": \"" + (float) (kalmandegree) + "\",\"distance\": \"" + (float) (round(stepCount * 100.0) / 100.0) + "\",\"time\": \"" + time + "\"}";
//                    String msg1 = "{\"x_Val\": \"" + x_val + "\",\"y_Val\": \"" + y_val + "\",\"degree\": \"" + degree + "\",\"rawDegree\": \"" + rawdegree + "\",\"compDegree\": \"" + compdegree+ "\",\"kalmanDegree\": \"" + kalmandegree + "\",\"stepCount\": \"" + stepCount + "\",\"time\": \"" + time + "\"}";

                    try {
                        this.message.put("topic", "SensorData");
                        this.message.put("x_Val", x_val);
                        this.message.put("y_Val", y_val);
                        this.message.put("degree", degree);
                        this.message.put("rawDegree", rawdegree);
                        this.message.put("compDegree", compdegree);
                        this.message.put("kalmanDegree", kalmandegree);
                        this.message.put("stepCount", stepCount);
                        this.message.put("time", time);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Intent in = new Intent("com.ashley.ashley");
                    Bundle extras = new Bundle();
                    extras.putString("com.ashley.ashley.mySensorData", this.message.toString());
                    in.putExtras(extras);
                    sendBroadcast(in);

                    if (dataFileWriter != null) {
                        dataFileWriter.writeToFile("Path", msg);
                    }
                    Log.d("TAG", msg);
                    sendToWebSocket(this.message);

                    prevXVal = x_val;
                    prevYVal = y_val;

                    prevDist = (float) distance;
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (broadcastReceiver != null) {
            unregisterReceiver(broadcastReceiver);
        }
        if (networkStateReceiver != null) {
            unregisterReceiver(networkStateReceiver);
        }


        //websocketServerCode started
        if (server != null) {
            try {
                server.stop();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //webSocketServerCode stopped
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    private void initJmDNSHelper() {
        jmDNSHelper = new JmDNSHelper(this);
        jmDNSHelper.setOperationMode(CLIENT_MODE);
        jmDNSHelper.setStationName("Chat-Server");
    }

    private void registerNSD() {
        if (jmDNSHelper != null && !jmDNSHelper.isServiceRegistered()) {
            jmDNSHelper.registerService();

        }
    }

    public void ensureConnectionToService() {
        pgManager.ensureConnectionToService(getApplicationContext());
    }

    public void onScannerConnectBtnClick(boolean isPinnedMode) {
        if (!pgManager.isConnectedToService()) {
            String msg = getString(R.string.connect_to_service_first);
            showMessage(msg, false);
            return;
        }

        if (pgManager.isConnectedToScanner()) {
            pgManager.disconnectScanner();
        } else if (isPinnedMode) {
            pgManager.startPairingFromPinnedActivity(this);
        } else {
            pgManager.startPairing();
        }
    }

    private void sendScreen(PgScreenData screenData) {
        if (pgManager.isConnectedToService() && pgManager.isConnectedToDisplay()) {
            pgManager.setScreen(screenData, new IPgSetScreenCallback() {
                @Override
                public void onSuccess() {
                    String msg = "Screen set successfully";
                    showMessage(msg, false);
                }

                @Override
                public void onError(@NonNull final PgError pgError) {
                    String msg = "Setting the screen failed. Error: " + pgError;
                    showMessage(msg, true);
                }
            });
        }
    }


    @SuppressLint("SetTextI18n")
    private void setDefaultImageConfiguration() {
        PgImageConfig defaultImageConfig = new PgImageConfig();
        defaultImageQuality = defaultImageConfig.getJpegQuality();
        // imageQualityET.setText("" + defaultImageQuality);
        //timeoutET.setText("" + DEFAULT_IMAGE_TIMEOUT);
    }

    private ImageResolution getSelectedImageResolution() {

        return ImageResolution.RESOLUTION_640_480;
        /*switch (resolutionRadioGroup.getCheckedRadioButtonId()) {
            case R.id.highResolution:
                return ImageResolution.RESOLUTION_1280_960;
            case R.id.mediumResolution:
                return ImageResolution.RESOLUTION_640_480;
            case R.id.lowResolution:
                return ImageResolution.RESOLUTION_320_240;
            default:
                return ImageResolution.values()[1];
        }*/
    }

    private void startTakingImage() {
        // String imageQualityString = imageQualityET.getText().toString();
        String imageQualityString = "20"; //image quality default
        int quality =
                imageQualityString.isEmpty() ? defaultImageQuality : Integer.parseInt(imageQualityString);

        //String timeoutString = timeoutET.getText().toString();
        String timeoutString = "10000"; //10,000 millisecs default
        int timeout = timeoutString.isEmpty() ? DEFAULT_IMAGE_TIMEOUT : Integer.parseInt(timeoutString);

        PgImageConfig imageConfig = new PgImageConfig(quality, getSelectedImageResolution());

        pgManager.takeImage(imageConfig, timeout, new IPgImageCallback() {
            @Override
            public void onImageReceived(@NonNull final PgImage pgImage) {
                final Bitmap bmp = BitmapFactory.decodeByteArray(pgImage.getBytes(), 0, pgImage.getBytes().length);


                /* runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        imageTakenIV.setImageBitmap(bmp);
                    }
                }); */
                try {

                    String path = Environment.getExternalStorageDirectory().toString();
                    OutputStream fOut = null;
                    Integer counter = 0;
                    File file = new File(path, "Proglove" + counter + ".jpg"); // the File to save , append increasing numeric counter to prevent files from getting overwritten.
                    fOut = new FileOutputStream(file);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
                    fOut.flush();
                    fOut.close(); //  close stream

                    MediaStore.Images.Media.insertImage(getContentResolver(), file.getAbsolutePath(), file.getName(), file.getName());
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onError(@NonNull final PgError pgError) {
                final String msg = "Taking an image failed. Error code is: " + pgError;
                showMessage(msg, true);
            }
        });

    }


    private void getpginfo() {
        pgManager.obtainDeviceVisibilityInfo(new IPgDeviceVisibilityCallback() {
            @Override
            public void onError(final PgError error) {
                // Handle error
                logger.log(Level.SEVERE, "Error during obtainDeviceVisibilityInfo: " + error.toString());

                String myMsg = "Error during obtainDeviceVisibilityInfo: " + error.toString();

                sendProgloveStringTowebSocket(myMsg);
            }

            @Override
            public void onDeviceVisibilityInfoObtained(@NonNull final DeviceVisibilityInfo deviceVisibilityInfo) {
                // content of deviceVisibilityInfo
                logger.log(Level.INFO, "deviceVisibilityInfo: " + deviceVisibilityInfo.toString());

                pgBatteryLevel = deviceVisibilityInfo.getBatteryLevel();
                pgSerial = deviceVisibilityInfo.getSerialNumber();
                pgFirmware = deviceVisibilityInfo.getFirmwareRevision();
                pgModel = deviceVisibilityInfo.getModelNumber();
                //pgModel = "Model test";

                JSONObject message = null;
                try {
                    message = new JSONObject("{\"BatteryLevl\": \"" + pgBatteryLevel + "\",\"Serial\": \"" + pgSerial + "\",\"Firmware\": \"" + pgFirmware + "\",\"Model\": \"" + pgModel);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                sendProgloveStringTowebSocket(message.toString());
            }
        });
    }



    private void sendProgloveStringTowebSocket(String s) {
        try {
            JSONObject jsonObj = new JSONObject("{\"topic\": \"Proglove\", \"text\": \"text\"}");
            jsonObj.put("text", s);
            sendToWebSocket(jsonObj);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void sendStringTowebSocket(String s) {
        try {
            JSONObject jsonObj = new JSONObject("{\"topic\": \"DebugMessage\", \"text\": \"text\"}");
            jsonObj.put("text", s);
            sendToWebSocket(jsonObj);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void sendToWebSocket(JSONObject text) {
        String androidId = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ANDROID_ID);
        String webMsg = "";
        try {
            text.put("deviceId", androidId);
            text.put("data", "Received from android Service");
            text.put("Response", true);
            if (text.getString("topic").equals("SensorData")) {
            } else {
                webMsg = text.toString();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        //weSocketServerCode Started
        if (webSocketServerRunning) {
            server.broadcast(text.toString());
        }
        //webSocketServerCode Ended

        if (SocketConnected) {
            mSocket.emit("iot-voice", text.toString());
        }

        Intent in = new Intent("com.ashley.ashley");
        Bundle extras = new Bundle();
        extras.putString("com.ashley.ashley.myString", webMsg);
        in.putExtras(extras);
        sendBroadcast(in);
    }

    public void startCounter() {
        SensorManager.registerListener(HelixForegroundService.this, sensorLinearAcceleration, SensorManager.SENSOR_DELAY_FASTEST);

        stepCount = staticStepCounters[0].getStepCount();

        Log.d(TAG, "stepcount is :" + stepCount);


        try {
            dataFileWriter = new DataFileWriter(FOLDER_NAME, ExtraFunctions.arrayToList(DATA_FILE_NAMES), ExtraFunctions.arrayToList(DATA_FILE_HEADINGS));
        } catch (IOException e) {
            e.printStackTrace();
        }
        requestNewLocationData();
    }

    public void stopCounter() {

        SensorManager.unregisterListener(HelixForegroundService.this, sensorLinearAcceleration);

        for (StaticStepCounter staticStepCounter : staticStepCounters) {
            staticStepCounter.clearStepCount();
        }

        mFusedLocationClient.removeLocationUpdates(mLocationCallback);
    }

    public void setDegreeSelected(String s) {
        this.degreeSelected = s;
    }

   public void setAllPermissionsGranted() {
        allPermissionsGranted=true;
    }

    public class LocalService extends Binder {
        HelixForegroundService getService() {
            return HelixForegroundService.this;
        }
    }

    private boolean InternetAvailable = false;
    private BroadcastReceiver networkStateReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = manager.getActiveNetworkInfo();
            if (ni != null) {
                InternetAvailable = true;

            } else {
                InternetAvailable = false;
                SocketConnected = false;
            }

        }
    };

   private JSONObject getParsedJSON(String json) {

        JSONObject jObj = null;
        try {
            jObj = new JSONObject(json);
        } catch (Exception e) {
            Log.e("JSON Parser", "Error parsing data " + e.toString());
            try {
                json = json.replaceAll("[\\\\]{1}[\"]{1}", "\"");
                jObj = new JSONObject(json.substring(json.indexOf("{"), json.lastIndexOf("}") + 1));
            } catch (Exception e0) {
                Log.e("JSON Parser0", "Error parsing data [" + e0.getMessage() + "] " + json);
                Log.e("JSON Parser0", "Error parsing data " + e0.toString());
                try {
                    jObj = new JSONObject(json.substring(1));
                } catch (Exception e1) {
                    Log.e("JSON Parser1", "Error parsing data [" + e1.getMessage() + "] " + json);
                    Log.e("JSON Parser1", "Error parsing data " + e1.toString());
                    try {
                        jObj = new JSONObject(json.substring(2));
                    } catch (Exception e2) {
                        Log.e("JSON Parser2", "Error parsing data [" + e2.getMessage() + "] " + json);
                        Log.e("JSON Parser2", "Error parsing data " + e2.toString());
                        try {
                            jObj = new JSONObject(json.substring(3));
                        } catch (Exception e3) {
                            Log.e("JSON Parser3", "Error parsing data [" + e3.getMessage() + "] " + json);
                            Log.e("JSON Parser3", "Error parsing data " + e3.toString());
                        }
                    }
                }
            }
        }

        // return JSON String
        return jObj;
    }

    //webSocketClient Started
    private void connectWebSocket() {
        URI uri;
        try {
            uri = new URI("ws://localhost:8080");

        } catch (URISyntaxException e) {
            e.printStackTrace();
            return;
        }

        mWebSocketClient = new WebSocketClient(uri) {
            @Override
            public void onOpen(ServerHandshake serverHandshake) {
                webSocketServerRunning = true;
                Log.i("WebsocketClient", "Opened");
                String androidId = Settings.Secure.getString(getContentResolver(),
                        Settings.Secure.ANDROID_ID);
                sendStringTowebSocket("Welcome to the server with device ID :: "+androidId);
            }

            @Override
            public void onMessage(String s) {
                doOnMessage(s);
            }

            @Override
            public void onClose(int i, String s, boolean b) {
                Log.i("WebsocketClient", "Closed " + s);
                handler.postDelayed(runnable, 3000);
//                sendStringTowebSocket("local WebSocket Client Closed " + s);
            }

            @Override
            public void onError(Exception e) {
                Log.i("WebsocketClient", "Error " + e.getMessage());
                sendStringTowebSocket("local WebSocket Client Error " + e.getMessage());
            }
        };
        mWebSocketClient.connect();
    }

    private void doOnMessage(String s) {

        Runnable r = new Runnable() {
            // notice the use of other variables here..
            @Override
            public void run() {
                String topicString = "";
                String deviceId = "";
                Boolean Response = false;
                Log.i("Websocket", "on Message " + s);
                String androidId = Settings.Secure.getString(getContentResolver(),
                        Settings.Secure.ANDROID_ID);
                JSONObject jsonObj = null;

                ArrayList<PgTemplateField> pgTemplateFieldArrayList = new ArrayList<PgTemplateField>();
              //  String sample= "{\"topic\":\"PGDisplay\",\"deviceId\":\"localhost\",\"templateid\":\"PG1\",\"header1\":\"head1\",\"content1\":\"cont1\"}";

                jsonObj = getParsedJSON(s);
                if (jsonObj != null) {
                    try {
                        topicString = jsonObj.getString("topic");

                        deviceId = jsonObj.getString("deviceId");
                        if (deviceId.equals("localhost")) {
                            deviceId = androidId;
                        }
                        if (jsonObj.has("Response")) {
                            Response = jsonObj.getBoolean("Response");
                        } else {
                            Response = false;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                if (topicString.equals("deviceInfo") && deviceId.equals(androidId) && !Response) {
                    getDeviceSuperInfo();
                }
                if (topicString.equals("capture") && deviceId.equals(androidId) && !Response) {
                    if (!captureImageRunning) {
                        Intent dialogIntent = new Intent(getApplicationContext(), CameraActivity.class);
                        dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        dialogIntent.putExtra("buttonNumber", 1);
                        startActivity(dialogIntent);
                        sendStringTowebSocket("Camera Opened");
                        captureImageRunning = true;
                    } else {
                        sendStringTowebSocket("Camera Already Opened");
                    }
                }
                if (topicString.equals("videocapture") && deviceId.equals(androidId) && !Response) {
                    if (!captureImageRunning) {
                        Intent dialogIntent = new Intent(getApplicationContext(), CameraActivity.class);
                        dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        dialogIntent.putExtra("buttonNumber", 2);
                        startActivity(dialogIntent);
                        sendStringTowebSocket("Camera Opened");
                        captureImageRunning = true;
                    } else {
                        sendStringTowebSocket("Camera Already Opened");
                    }
                }
                if (topicString.equals("scan") && deviceId.equals(androidId) && !Response) {
                    if (!CameraRunning) {
                        String msg = "Stop Main";

                        Intent in = new Intent("com.ashley.ashley");
                        Bundle extras = new Bundle();
                        extras.putString("com.ashley.ashley.STOPMAIN", msg);
                        in.putExtras(extras);
                        sendBroadcast(in);

                        Intent dialogIntent = new Intent(getApplicationContext(), QRCodeScanActivity.class);
                        dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(dialogIntent);
                        sendStringTowebSocket("Camera Opened");
                        CameraRunning = true;

                    } else {
                        sendStringTowebSocket("Camera Already Opened");
                    }
                }

                if (topicString.equals("getPGInfo") && deviceId.equals(androidId) && !Response) {
                    getpginfo();
                }
                if (topicString.equals("PGTriggerMessage") && deviceId.equals(androidId) && !Response) {
                    try {
                        if (jsonObj.getString("Message") != null) {
                            triggerFeedback(jsonObj.getString("Message"));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                if (topicString.equals("blockTrigger") && deviceId.equals(androidId) && !Response) {
                    blockTrigger();
                }
                if (topicString.equals("unBlockTrigger") && deviceId.equals(androidId) && !Response) {
                    unblockTrigger();
                }
                if (topicString.equals("PGDisplay") && deviceId.equals(androidId) && !Response) {

                    String header1 = null,header2=null,header3=null,content1=null,
                            content2=null,content3 = null, pgTemplate=null;
                    try {
                        if (jsonObj.has("header1")) {
                            header1 = jsonObj.getString("header1");
                        }
                        if (jsonObj.has("header2")) {
                            header2 = jsonObj.getString("header2");
                        }
                        if (jsonObj.has("header3")) {
                            header3 = jsonObj.getString("header3");
                        }
                        if (jsonObj.has("content1")) {
                            content1 = jsonObj.getString("content1");
                        }
                        if (jsonObj.has("content2")) {
                            content2 = jsonObj.getString("content2");
                        }
                        if (jsonObj.has("content3")) {
                            content3 = jsonObj.getString("content3");
                        }
                        pgTemplate = jsonObj.getString("templateid");

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if(header1!=null && content1 !=null)
                    {
                        pgTemplateFieldArrayList.add( new PgTemplateField(1, header1, content1)) ;
                    }
                    if(header2!=null && content2 !=null)
                    {
                        pgTemplateFieldArrayList.add( new PgTemplateField(2, header2, content2)) ;
                    }
                    if(header3!=null && content3 !=null)
                    {
                         pgTemplateFieldArrayList.add( new PgTemplateField(3, header3, content3)) ;
                    }
                    PgScreenData screenData = new PgScreenData(pgTemplate, pgTemplateFieldArrayList, RefreshType.DEFAULT,0);
                    sendScreen(screenData);
                }
            }
        };
        Thread t = new Thread(r);
        t.start();


    }
    //webSocketClient ended

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Helix Foreground Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    @Override
    public void onServiceConnected() {
        Intent in = new Intent("com.ashley.ashley");
        Bundle extras = new Bundle();
        try {
            progloveJson.put("ServiceStatus", pgManager.isConnectedToService());
            progloveJson.put("ScannerStatus", pgManager.isConnectedToScanner());
            progloveJson.put("DisplayStatus", pgManager.isConnectedToDisplay());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        extras.putString("com.ashley.ashley.ServiceStatus", progloveJson.toString());
        in.putExtras(extras);
        sendBroadcast(in);
        sendProgloveStringTowebSocket("Proglove Service Connected!");
//        sendProgloveStringTowebSocket(progloveJson.toString());
    }

    @Override
    public void onServiceDisconnected() {
        Intent in = new Intent("com.ashley.ashley");
        Bundle extras = new Bundle();
        try {
            progloveJson.put("ServiceStatus", pgManager.isConnectedToService());
            progloveJson.put("ScannerStatus", pgManager.isConnectedToScanner());
            progloveJson.put("DisplayStatus", pgManager.isConnectedToDisplay());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        extras.putString("com.ashley.ashley.ServiceStatus", progloveJson.toString());
        in.putExtras(extras);
        sendBroadcast(in);
        sendProgloveStringTowebSocket("Proglove Service Disconnected!");
//        sendProgloveStringTowebSocket(progloveJson.toString());

    }

    @Override
    public void onButtonPressed(@NonNull final ButtonPress buttonPress) {
        String msg = getString(R.string.button_pressed, buttonPress.getId());
        showMessage(msg, false);
    }

    @Override
    public void onPgTriggersUnblocked() {
        String myMsg = "Proglove Triggers UnBlocked Now";

        try {
            JSONObject jsonObj = new JSONObject("{\"topic\": \"Proglove\", \"text\": \"text\"}");
            jsonObj.put("text", myMsg);
            sendToWebSocket(jsonObj);
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onScannerConfigurationChange(PgScannerConfigurationChangeResult scannerConfigurationChange) {

        String message = "";
        if (scannerConfigurationChange.getScannerConfigurationChangeStatus() == ScannerConfigurationChangeStatus.Success.INSTANCE) {
            message = "Scanner configuration successfully changed";
        } else if (scannerConfigurationChange.getScannerConfigurationChangeStatus() == ScannerConfigurationChangeStatus.NoScannerConfiguration.INSTANCE) {
            message = "No scanner configuration in the profile";
        } else if (scannerConfigurationChange.getScannerConfigurationChangeStatus() == ScannerConfigurationChangeStatus.Unknown.INSTANCE) {
            message = "Unknown set scanner configuration status";
        } else if (scannerConfigurationChange.getScannerConfigurationChangeStatus() instanceof ScannerConfigurationChangeStatus.Error) {
            message = "Fail to change scanner configuration, error: " + ((ScannerConfigurationChangeStatus.Error) scannerConfigurationChange.getScannerConfigurationChangeStatus()).getCause().toString();
        }

        // Send via websocket
        sendProgloveStringTowebSocket(message);
        // Refresh the profiles list
        getConfigProfiles();
    }

    private void getConfigProfiles() {
        pgManager.getConfigProfiles(
                new IPgGetConfigProfilesCallback() {
                    @Override
                    public void onConfigProfilesReceived(@NonNull PgConfigProfile[] profiles) {
                        Log.d(TAG, "received " + profiles.length + " config profiles");

                        final ArrayList<ProfileUiData> uiProfiles = new ArrayList<>();
                        for (PgConfigProfile profile : profiles) {
                            uiProfiles.add(new ProfileUiData(profile.getProfileId(), profile.isActive()));
                        }
                    }

                    @Override
                    public void onError(@NonNull final PgError pgError) {

                    }
                }
        );
    }

    @Override
    public void onScannerConnected() {

    }

    @Override
    public void onScannerDisconnected() {

    }

    @Override
    public void onScannerStateChanged(@NonNull ConnectionStatus connectionStatus) {
        Intent in = new Intent("com.ashley.ashley");
        Bundle extras = new Bundle();
        try {
            progloveJson.put("ServiceStatus", pgManager.isConnectedToService());
            progloveJson.put("ScannerStatus", pgManager.isConnectedToScanner());
            progloveJson.put("DisplayStatus", pgManager.isConnectedToDisplay());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        extras.putString("com.ashley.ashley.ServiceStatus", progloveJson.toString());

        in.putExtras(extras);
        sendBroadcast(in);
        // Add Websocket code to send connection status

        String myMsg = "Proglove connection Status : " + connectionStatus.toString();

        sendProgloveStringTowebSocket(myMsg);
        sendProgloveStringTowebSocket(progloveJson.toString());

    }

    @Override
    public void onDisplayConnected() {

    }

    @Override
    public void onDisplayDisconnected() {

    }

    @Override
    public void onDisplayStateChanged(@NonNull ConnectionStatus connectionStatus) {

        Intent in = new Intent("com.ashley.ashley");
        Bundle extras = new Bundle();
        try {
            progloveJson.put("ServiceStatus", pgManager.isConnectedToService());
            progloveJson.put("ScannerStatus", pgManager.isConnectedToScanner());
            progloveJson.put("DisplayStatus", pgManager.isConnectedToDisplay());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        extras.putString("com.ashley.ashley.ServiceStatus", progloveJson.toString());

        in.putExtras(extras);
        sendBroadcast(in);
        // Add Websocket code to send connection status

        String myMsg = "Proglove connection Status : " + connectionStatus.toString();
        sendProgloveStringTowebSocket(myMsg);
        sendProgloveStringTowebSocket(progloveJson.toString());
    }

    private void showMessage(final String msg, final boolean isError) {
        if (isError) {
            Log.e(TAG, msg);
        } else {
            Log.d(TAG, msg);
        }
        String myMsg = "Proglove Connected " + msg;
        sendProgloveStringTowebSocket(myMsg);

    }

    private PgPredefinedFeedback getSelectedFeedback(String S) {
//        return PgPredefinedFeedback.SUCCESS; //GREEN
        switch (S) {
            case "feedbackSuccess":
                return PgPredefinedFeedback.SUCCESS; //GREEN
            case "feedbackError":
                return PgPredefinedFeedback.ERROR; // RED
            case "feedbackInfo":
                return PgPredefinedFeedback.SPECIAL_1; //YELLOW
            default:
                Log.d(TAG, "getSelectedFeedback: Nothing is selected, returning ERROR as default value.");
                return PgPredefinedFeedback.ERROR;
        }

    }

    private void triggerFeedback(String S) {
        // boolean replaceQueueSwitchChecked = sendFeedbackWithReplaceQueueSwitch.isChecked();
        boolean replaceQueueSwitchChecked = true; //send feedback with replace queue ? change to false if needed.
        // Creating new PgCommandParams setting the queueing behaviour
        PgCommandParams params = new PgCommandParams(replaceQueueSwitchChecked);
        // Wrapping the feedback data in a PgCommand with the PgCommandData
        PgCommand<PgPredefinedFeedback> feedbackCommand = getSelectedFeedback(S).toCommand(params);
        pgManager.triggerFeedback(feedbackCommand, new IPgFeedbackCallback() {
            @Override
            public void onSuccess() {
                Log.d(TAG, "Feedback successfully played.");
            }

            @Override
            public void onError(@NonNull PgError pgError) {
                final String msg = "An Error occurred during triggerFeedback: " + pgError;
                showMessage(msg, true);
            }
        });

    }

    private void blockTrigger() {
        pgManager.blockPgTrigger(
                new PgCommand<>(new BlockPgTriggersParams(
                        Collections.singletonList(PredefinedPgTrigger.DefaultPgTrigger.INSTANCE),
                        Collections.singletonList(PredefinedPgTrigger.DoubleClickMainPgTrigger.INSTANCE),
                        0,
                        true)),
                new IBlockPgTriggersCallback() {
                    @Override
                    public void onBlockTriggersCommandSuccess() {
                        String myMsg = "Proglove Block Trigger Command Success ";
                        sendProgloveStringTowebSocket(myMsg);
                    }

                    @Override
                    public void onError(@NonNull final PgError error) {
                        String myMsg = "Proglove Block Trigger Command Error ";
                        sendProgloveStringTowebSocket(myMsg + ", error: " + error.toString());
                    }
                });
    }

    private void unblockTrigger() {
        pgManager.blockPgTrigger(
                new PgCommand<>(new BlockPgTriggersParams(Collections.<PredefinedPgTrigger>emptyList(), Collections.<PredefinedPgTrigger>emptyList(), 0, false)),
                new IBlockPgTriggersCallback() {
                    @Override
                    public void onBlockTriggersCommandSuccess() {
                        String myMsg = "Proglove Un Block Trigger Command Success ";
                        sendProgloveStringTowebSocket(myMsg);
                    }

                    @Override
                    public void onError(@NonNull final PgError error) {
                        String myMsg = "Proglove Un Block Trigger Command Error ";
                        sendProgloveStringTowebSocket(myMsg + ", error: " + error.toString());
                    }
                });
    }

    @Override
    public void onBarcodeScanned(@NonNull final BarcodeScanResults barcodeScanResults) {
        updateScannedResults(barcodeScanResults);
    }

    private void updateScannedResults(@NonNull BarcodeScanResults barcodeScanResults) {

        String symbology = barcodeScanResults.getSymbology();
        if (symbology == null) {
            symbology = "";
        }
        Intent in = new Intent("com.ashley.ashley");
        Bundle extras = new Bundle();
        try {
            progloveJson.put("ServiceStatus", pgManager.isConnectedToService());
            progloveJson.put("ScannerStatus", pgManager.isConnectedToScanner());
            progloveJson.put("DisplayStatus", pgManager.isConnectedToDisplay());
            progloveJson.put("resultSymbology", symbology);
            progloveJson.put("scannerResult", barcodeScanResults.getBarcodeContent());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        extras.putString("com.ashley.ashley.ServiceStatus", progloveJson.toString());
        in.putExtras(extras);
        sendBroadcast(in);
        sendProgloveStringTowebSocket(progloveJson.toString());
        String msg = !symbology.isEmpty() ?
                getString(R.string.new_scan_notification, barcodeScanResults.getBarcodeContent(), symbology) :
                getString(R.string.new_scan_no_symbology_notification, barcodeScanResults.getBarcodeContent());
        // showMessage(msg, false);
        sendProgloveStringTowebSocket(msg);
    }


}