package com.ashley.ashley;


import static java.lang.Math.round;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.ashley.ashley.databinding.ActivityMainBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

//Proglove Integration 4


public class MainActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_CODE = 123;
    private BroadcastReceiver broadcastReceiver;
    private static final int PERMISSIONS_REQUEST_RECORD_AUDIO = 1;
    //Proglove Integrate 5


    HelixForegroundService myService;
    boolean isBind = false;
//    private Model mainActivityModel;

    /* Used to handle permission request */


    //SENSOR MANAGER
    private ActivityMainBinding binding;

    private static final String TAG = "MainActivity";


    TextView xValue, yValue, zValue, Gyrox, Gyroy, Gyroz, Magnx, Magny, Magnz, Rvectorx, Rvectory, Rvectorz, Rdegree, jsontext, StepView, Direction, distTanceCounter, webText;
    CheckBox rawdegree, compdegree, kalmandegree, INA260Selector;
    EditText xTarget, yTarget, xStart, yStart;
    StringBuilder builder = new StringBuilder();
    float[] history = new float[2];
    String[] direction = {"NONE", "NONE"};
    private double MagnitudePrevious = 0;

    String degreeSelected = "rawdegree";

    private float prevDegree = 0;
    private String Compass_dir;

    private FloatPoint sp = new FloatPoint(0, 0);
    private FloatPoint prevIntersectPoint = new FloatPoint(0, 0);
    private FloatPoint ep = new FloatPoint(500, 1500);
    private int firstCycle = 0;
    private int margin = 20;

    //Proglove initialisations 1
    private Button test11;
    private Button serviceConnectBtn;
    private Button scannerConnectBtn;
    public TextView displayStateTV;
    private Button disconnectDisplayBtn;
    private Button sendTestScreenBtn, sendTestScreenFailBtn, pickDisplayOrientationDialogBtn;
    private TextView scannerResultTV;
    private TextView resultSymbologyTV;
    private Button takeImageButtonBtn;
    private int defaultImageQuality;
    private static int DEFAULT_IMAGE_TIMEOUT = 10000;
    private Button triggerFeedbackBtn;
    private RadioGroup feedbackRadioGroup;
    private Switch defaultFeedbackSwitch;
    private int pgBatteryLevel;
    private String pgSerial;
    private String pgFirmware;
    private String pgModel;
    private Button pgInfobtn;
    private TextView pgbatteryLevelTV, pgSerialTV, pgModelTV;
    private Button blockTriggerBtn;
    private Button blockAllTriggersBtn;
    private Button unblockTriggerBtn;
    private Button buttonStartCounter;
    private Button buttonStopCounter;
    private Button buttonPic;
    private Button buttonVid;

    private boolean audioPermitted = false;
    final Handler handler = new Handler();
    private static final String FILE_NAME = "myVariables.json";
    private Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent serviceIntent = new Intent(this, HelixForegroundService.class);
        serviceIntent.putExtra("inputExtra", "Main Service Started");
        bindService(serviceIntent, mConnection, Context.BIND_AUTO_CREATE);

        ContextCompat.startForegroundService(MainActivity.this, serviceIntent);


        registerReceiver();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkPermission();
        }
        // Function to check and request permission.

        // Check if user has given permission to record audio, init the model after permission is granted
        int permissionCheck = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.RECORD_AUDIO);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSIONS_REQUEST_RECORD_AUDIO);
        } else {
            audioPermitted = true;

        }


//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            ActivityCompat.requestPermissions(this,
//                    new String[]{
//                            Manifest.permission.READ_EXTERNAL_STORAGE,
//                            Manifest.permission.WRITE_EXTERNAL_STORAGE
//                    }, PERMISSIONS_REQUEST_STORAGE
//            );
//        }

        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, 0);
        }

        try {
            updateButtonStates(false, false, false);
        } catch (Exception e) {
            e.printStackTrace();
        }
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        xValue = (TextView) findViewById(R.id.xValue);
        yValue = (TextView) findViewById(R.id.yValue);
        zValue = (TextView) findViewById(R.id.zValue);
        webText = (TextView) findViewById(R.id.webText);
        webText.setMovementMethod(new ScrollingMovementMethod());
        String androidId = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ANDROID_ID);
        webText.append("Events for " + androidId + " shown here:");

        Gyrox = (TextView) findViewById(R.id.Gyrox);
        Gyroy = (TextView) findViewById(R.id.Gyroy);
        Gyroz = (TextView) findViewById(R.id.Gyroz);

        Magnx = (TextView) findViewById(R.id.Magnx);
        Magny = (TextView) findViewById(R.id.Magny);
        Magnz = (TextView) findViewById(R.id.Magnz);

        rawdegree = (CheckBox) findViewById(R.id.rawdegree);
        compdegree = (CheckBox) findViewById(R.id.compdegree);
        INA260Selector = (CheckBox) findViewById(R.id.INA260Selector);
        kalmandegree = (CheckBox) findViewById(R.id.kalmandegree);
        rawdegree.setChecked(true);

        Rdegree = (TextView) findViewById(R.id.Rdegree);
        jsontext = (TextView) findViewById(R.id.jsontext);
//        StepView = (TextView) findViewById(R.id.jsontext);
        Direction = (TextView) findViewById(R.id.Direction);

        xTarget = (EditText) findViewById(R.id.xTarget);
        yTarget = (EditText) findViewById(R.id.yTarget);
        xTarget.setText("" + (int) ep.x);
        yTarget.setText("" + (int) ep.y);
        xStart = (EditText) findViewById(R.id.xStart);
        yStart = (EditText) findViewById(R.id.yStart);
        xStart.setText("" + (int) sp.x);
        yStart.setText("" + (int) sp.y);

        buttonStartCounter = (Button) findViewById(R.id.stepbuttonstart);
        buttonStopCounter = (Button) findViewById(R.id.stepbuttonstop);
        distTanceCounter = (TextView) findViewById(R.id.DistanceCount);
        buttonPic = (Button) findViewById(R.id.button);
        buttonVid = (Button) findViewById(R.id.button3);

        //Proglove UI
        // test11 = (Button) findViewById(R.id.test2);
        Button serviceConnectBtn = (Button) findViewById(R.id.serviceConnectBtn1);
        this.serviceConnectBtn = serviceConnectBtn;
        scannerConnectBtn = (Button) findViewById(R.id.connectScannerRegularBtn);
        scannerResultTV = findViewById(R.id.inputField);
        resultSymbologyTV = findViewById(R.id.symbologyResult);
        displayStateTV = findViewById(R.id.displayStateOutput);
        //    takeImageButtonBtn = findViewById(R.id.takeImageButton);
        //   feedbackRadioGroup = findViewById(R.id.radioGroup);
        //   feedbackRadioGroup.check(R.id.feedbackSuccess);//default select success radio button
        //  triggerFeedbackBtn = findViewById(R.id.triggerFeedbackButton);
        //  pickDisplayOrientationDialogBtn = findViewById(R.id.pickDisplayOrientationDialogBtn);
        //  pgbatteryLevelTV = findViewById(R.id.pgBatterylevel);
        //  pgSerialTV = findViewById(R.id.pgSerialNumber);
        //  pgModelTV = findViewById(R.id.pgModelNumber);
        // pgInfobtn = findViewById(R.id.pgInfobtn);
        //  blockTriggerBtn = findViewById(R.id.blockTriggerButton);
        // blockAllTriggersBtn = findViewById(R.id.blockAllTriggersButton);
        //  unblockTriggerBtn = findViewById(R.id.unblockTriggerButton);


        buttonStartCounter.setEnabled(true);
        buttonStopCounter.setEnabled(false);

        buttonPic.setEnabled(true);
        buttonVid.setEnabled(true);

        buttonPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraIntent(1);
            }
        });

        buttonVid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraIntent(2);
            }
        });

        buttonStartCounter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //TODO: enable this
                //staticStepCounters[0].setThresholds(upperThreshold, lowerThreshold);

                buttonStartCounter.setEnabled(false);
                buttonStopCounter.setEnabled(true);

                myService.startCounter();

            }
        });

        buttonStopCounter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                buttonStartCounter.setEnabled(true);
                buttonStopCounter.setEnabled(false);

                myService.stopCounter();

            }
        });

        // Prolgove Integration 7
        //Proglove button on click listeners
        serviceConnectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // go1();
                myService.ensureConnectionToService();
            }
        });

        // Pair scanner
        scannerConnectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myService.onScannerConnectBtnClick(false);
                // go1();
            }
        });

    }




    //proglove Integration 2
    void updateButtonStates(boolean isConnectedToService, boolean isConnectedToScanner, boolean isConnectedToDisplay) {
        updateServiceButtons(isConnectedToService, isConnectedToScanner);
        updateScannerButtons(isConnectedToService, isConnectedToScanner);
        updateDisplayConnectionState(isConnectedToService, isConnectedToScanner);
    }

    private void updateScannedResults(String scannerResult, String resultSymbology) {
        scannerResultTV.setText(scannerResult);

        resultSymbologyTV.setText(resultSymbology);
    }

    private void updateServiceButtons(boolean isConnectedToService, boolean isConnectedToScanner) {
        if (isConnectedToService && isConnectedToScanner) {
            serviceConnectBtn.setEnabled(false);
            serviceConnectBtn.setText(R.string.service_connected);

        } else {
            serviceConnectBtn.setEnabled(true);
            serviceConnectBtn.setText(R.string.connect_service);

        }
    }

    private void updateScannerButtons(boolean isConnectedToService, boolean isConnectedToScanner) {
        if (isConnectedToService && isConnectedToScanner) {
            scannerConnectBtn.setText(R.string.scanner_connected);

        } else {
            scannerConnectBtn.setText("pair");
        }
    }

    private void updateDisplayConnectionState(boolean isConnectedToService, boolean isConnectedToDisplay) {
        if (isConnectedToService && isConnectedToDisplay) {

            displayStateTV.setText(R.string.display_connected);
        } else {
            displayStateTV.setText(R.string.display_disconnected);
        }

    }


    //Proglove Integration 3

    private void registerReceiver() {
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String killMsg = intent.getStringExtra("com.ashley.ashley.COMM");
                if (killMsg != null) {
                    if (killMsg.equals("KILL")) {
                        finishAndRemoveTask();
                        android.os.Process.killProcess(android.os.Process.myPid());
                    }else if(killMsg.equals("RESTART")){
                        handler.postDelayed(runnable, 3000);
                    } else {
                        webText.append("\n-----------------------------------");
                        webText.append("\n" + killMsg);
                        webText.bringPointIntoView(webText.length());
//                        Toast.makeText(getBaseContext(),killMsg,Toast.LENGTH_LONG).show();
                    }
                }
                String myMsg = intent.getStringExtra("com.ashley.ashley.myString");
                if (myMsg != null && !myMsg.isEmpty()) {
                    webText.append("\n-----------------------------------");
                    webText.append("\n" + myMsg);
                    if (webText.getLineCount() > webText.getMaxLines()) {
                        webText.getEditableText().delete(0, webText.getText().length() - 200);
                    }
                    webText.bringPointIntoView(webText.length());
                    try {
                        JSONObject obj = new JSONObject(myMsg);
                        if (obj.getString("topic").equals("DebugMessage")) {

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                String S = intent.getStringExtra("com.ashley.ashley.mySensorData");
                if (S != null) {
                    try {
                        JSONObject jsonObj = new JSONObject(S);
                        int stepCount = jsonObj.getInt("stepCount");
                        distTanceCounter.setText("Count: " + (int) stepCount);
                        double rawDegree = jsonObj.getDouble("rawDegree");
                        Rdegree.setText("RawDegree: " + (float) (round(rawDegree * 100.0) / 100.0));
                        double compDegree = jsonObj.getDouble("compDegree");
                        jsontext.setText("CompFilter: " + (float) (round(compDegree * 100.0) / 100.0));
                        double kalmanDegree = jsonObj.getDouble("kalmanDegree");
                        Magnz.setText("Kalman: " + (float) (round(kalmanDegree * 100.0) / 100.0));

                        double x_val = jsonObj.getDouble("x_Val");
                        Magnx.setText(" x_val: " + (float) (round(x_val * 100.0) / 100.0));
                        double y_val = jsonObj.getDouble("y_Val");
                        Magny.setText(" y_val: " + (float) (round(y_val * 100.0) / 100.0));

                        int degree = jsonObj.getInt("degree");
                        if (degree > 338 && degree < 359 || degree > 1 && degree < 23) {
                            Direction.setText(" Dir:North ");
                            Compass_dir = "North  ";
                        } else if (degree > 359 && degree < 360 || degree > 0 && degree < 1) {
                            Direction.setText(" Dir:True-North");
                            Compass_dir = "T-North";
                        } else if (degree > 23 && degree < 67) {
                            Direction.setText(" Dir: N-East ");
                            Compass_dir = "N-East ";
                        } else if (degree > 68 && degree < 112) {
                            Direction.setText(" Dir: East ");
                            Compass_dir = "East  ";
                        } else if (degree > 113 && degree < 157) {
                            Direction.setText(" Dir: S-East ");
                            Compass_dir = "S-East";
                        } else if (degree > 158 && degree < 202) {
                            Direction.setText(" Dir: South ");
                            Compass_dir = "South ";
                        } else if (degree > 203 && degree < 247) {
                            Direction.setText(" Dir: S-West ");
                            Compass_dir = "S-West";
                        } else if (degree > 247 && degree < 292) {
                            Direction.setText(" Dir: West ");
                            Compass_dir = "West  ";
                        } else if (degree > 292 && degree < 337) {
                            Direction.setText(" Dir: N-West ");
                            Compass_dir = "N-West";
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                String onConnectSensor = intent.getStringExtra("com.ashley.ashley.ServiceStatus");
                if (onConnectSensor != null) {
                    try {
                        JSONObject senSorStatus = new JSONObject(onConnectSensor);
                        updateButtonStates(senSorStatus.getBoolean("ServiceStatus"), senSorStatus.getBoolean("ScannerStatus"), senSorStatus.getBoolean("DisplayStatus"));
                        updateScannedResults(senSorStatus.getString("scannerResult"), senSorStatus.getString("resultSymbology"));

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                String closeActivity = intent.getStringExtra("com.ashley.ashley.STOPMAIN");
                if (closeActivity != null) {
                    finishAndRemoveTask();
                }

            }
        };
        registerReceiver(broadcastReceiver, new IntentFilter("com.ashley.ashley"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (broadcastReceiver != null) {
            unregisterReceiver(broadcastReceiver);
        }
    }


    protected void checkPermission() {
        Activity mActivity = MainActivity.this;
        if (ContextCompat.checkSelfPermission(mActivity, Manifest.permission.CAMERA)
                + ContextCompat.checkSelfPermission(
                mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                + ContextCompat.checkSelfPermission(
                mActivity, Manifest.permission.RECORD_AUDIO)
                + ContextCompat.checkSelfPermission(
                mActivity, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Do something, when permissions not granted
            if (ActivityCompat.shouldShowRequestPermissionRationale(
                    mActivity, Manifest.permission.CAMERA)
                    || ActivityCompat.shouldShowRequestPermissionRationale(
                    mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    || ActivityCompat.shouldShowRequestPermissionRationale(
                    mActivity, Manifest.permission.RECORD_AUDIO)
                    || ActivityCompat.shouldShowRequestPermissionRationale(
                    mActivity, Manifest.permission.ACCESS_FINE_LOCATION)) {
                // If we should give explanation of requested permissions

                // Show an alert dialog here with request explanation
                AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
                builder.setMessage("Camera, Audio, Location and Write External" +
                        " Storage permissions are required to do the task.");
                builder.setTitle("Please grant those permissions");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityCompat.requestPermissions(
                                mActivity,
                                new String[]{
                                        Manifest.permission.CAMERA,
                                        Manifest.permission.RECORD_AUDIO,
                                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                        Manifest.permission.ACCESS_FINE_LOCATION
                                },
                                MY_PERMISSIONS_REQUEST_CODE
                        );
                    }
                });
                builder.setNeutralButton("Cancel", null);
                AlertDialog dialog = builder.create();
                dialog.show();
            } else {
                // Directly request for required permissions, without explanation
                ActivityCompat.requestPermissions(
                        mActivity,
                        new String[]{
                                Manifest.permission.CAMERA,
                                Manifest.permission.RECORD_AUDIO,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.ACCESS_FINE_LOCATION
                        },
                        MY_PERMISSIONS_REQUEST_CODE
                );
            }
        } else {
            audioPermitted=true;
            // Do something, when permissions are already granted
            Toast.makeText(MainActivity.this, "Permissions already granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_CODE: {
                // When request is cancelled, the results array are empty
                if (
                        (grantResults.length > 0) &&
                                (grantResults[0]
                                        + grantResults[1]
                                        + grantResults[2]
                                        + grantResults[3]
                                        == PackageManager.PERMISSION_GRANTED
                                )
                ) {
                    // Permissions are granted

                    audioPermitted=true;

                    Toast.makeText(MainActivity.this, "Permissions granted.", Toast.LENGTH_SHORT).show();
                } else {
                    // Permissions are denied
                    audioPermitted=false;
                    Toast.makeText(MainActivity.this, "Permissions denied.", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

            HelixForegroundService.LocalService localService = (HelixForegroundService.LocalService) service;
            myService = localService.getService();

            isBind = true;
            if(isBind && audioPermitted){
                myService.setAllPermissionsGranted();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBind = false;
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        if (!isBind) {
            Intent serviceIntent = new Intent(this, HelixForegroundService.class);
            serviceIntent.putExtra("inputExtra", "Main Service Started");
            bindService(serviceIntent, mConnection, Context.BIND_AUTO_CREATE);
            isBind = false;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (isBind) {
            unbindService(mConnection);
            isBind = false;
        }
        handler.removeCallbacks(runnable);
    }

    public void rawdegreeSelector(View v) {
        if (rawdegree.isChecked()) {
            degreeSelected = "rawdregree";
            compdegree.setChecked(false);
            kalmandegree.setChecked(false);
            myService.setDegreeSelected("rawdregree");
        }
    }

    public void compdegreeSelector(View v) {
        if (compdegree.isChecked()) {
            degreeSelected = "compdegree";
            rawdegree.setChecked(false);
            kalmandegree.setChecked(false);
            myService.setDegreeSelected("compdegree");
        }
    }

    public void kalmandegreeSelector(View v) {
        if (kalmandegree.isChecked()) {
            degreeSelected = "kalmandegree";
            compdegree.setChecked(false);
            rawdegree.setChecked(false);
            myService.setDegreeSelected("kalmandegree");
        }
    }

   public void openHelix(View v) {

        Intent i = new Intent(getApplicationContext(), HelixActivity.class);
        startActivity(i);

    }
    public void disableDeveloperMode(View v) {

            setVariable("developerMode", String.valueOf(false));
            Intent i = new Intent(getApplicationContext(), UserMainActivity.class);
            startActivity(i);


    }
    //datafile started
    public void setVariable(String variableName, String variableValue){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject = new JSONObject(readFromFile());
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            jsonObject.put(variableName, variableValue);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            writeToFile(jsonObject);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public String getVariable(String variableName){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject = new JSONObject(readFromFile());
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String variableValue=null;
        try {
            variableValue=jsonObject.get(variableName).toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return variableValue;
    }

    public void writeToFile(JSONObject JsonObject) throws IOException {
        // Convert JsonObject to String Format
        String userString = JsonObject.toString();
// Define the File Path and its Name
        File file = new File(this.getApplicationContext().getFilesDir(),FILE_NAME);
        FileWriter fileWriter = new FileWriter(file);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        bufferedWriter.write(userString);
        bufferedWriter.close();
    }
    public String readFromFile() throws IOException {
        File file = new File(this.getApplicationContext().getFilesDir(),FILE_NAME);
        FileReader fileReader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        StringBuilder stringBuilder = new StringBuilder();
        String line = bufferedReader.readLine();
        while (line != null){
            stringBuilder.append(line).append("\n");
            line = bufferedReader.readLine();
        }
        bufferedReader.close();
// This responce will have Json Format String
        String responce = stringBuilder.toString();
        return responce;
    }



    public void Scanbtn(View v) {
        Intent i = new Intent(getApplicationContext(), QRCodeScanActivity.class);
        startActivity(i);
    }

    public void cameraIntent(int id) {
        Intent i = new Intent(getApplicationContext(), CameraActivity.class);
        i.putExtra("buttonNumber", id);
        startActivity(i);
    }



};







