package com.ashley.ashley.net;

import com.ashley.ashley.HelixForegroundService;
import com.ashley.ashley.models.Frame;
import com.ashley.ashley.models.MemberData;
import com.ashley.ashley.models.Message;
import com.ashley.ashley.utils.LogHelper;
import com.ashley.ashley.utils.WrapHelper;
import com.google.gson.Gson;

import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import static com.ashley.ashley.utils.Config.CMD_MSG;
import static com.ashley.ashley.utils.Config.CMD_REG_USER;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

/**
 * Created by teocci.
 *
 * @author teocci@yandex.com on 2018-Aug-16
 */
public class ChatServer extends WebSocketServer {
    private final String TAG = "ChatServer";

    public ChatServer(int port) {
        super(new InetSocketAddress(port));
    }

    public ChatServer(InetSocketAddress address) {
        super(address);
    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {
        conn.send("Welcome to the server!"); //This method sends a message to the new client
        broadcast("new connection: " + handshake.getResourceDescriptor()); //This method sends a message to all clients connected
        Log.d(TAG, "new connection to " + conn.getRemoteSocketAddress());
    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        broadcast(WrapHelper.resToJson(conn + " has left the room!"));
        Log.d(TAG, conn + " has left the room!");
    }

    @Override
    public void onMessage(WebSocket conn, String message) {
        Log.d(TAG, "received message from " + conn.getRemoteSocketAddress() + ": " + message);
        if (WrapHelper.resToJson(message).contains("cmd")) {
            try {
                JSONObject j = null;
                j = new JSONObject(WrapHelper.resToJson(message));
                if (j != null) {
                    broadcast(j.getString("text"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onMessage(WebSocket conn, ByteBuffer message) {
        broadcast(message.array());
        Log.d(TAG, conn + ": " + message);
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        ex.printStackTrace();
        if (conn != null) {
            // some errors like port binding failed may not be assignable to a specific websocket
        }
    }

    @Override
    public void onStart() {
        Log.d(TAG, "Server started!");

        setConnectionLostTimeout(0);
        setConnectionLostTimeout(100);
    }
}