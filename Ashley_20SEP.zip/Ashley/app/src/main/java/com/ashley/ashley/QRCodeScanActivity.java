package com.ashley.ashley;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanIntentResult;
import com.journeyapps.barcodescanner.ScanOptions;

import org.json.JSONException;
import org.json.JSONObject;

public class QRCodeScanActivity extends AppCompatActivity {

    ImageView imageViewQR;
    TextView scanResult;
    TextView scanFormat;
    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
            result -> {
                this.onActivityResult(result);
            });
    Button buttonQR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode_scan);
        scanResult = findViewById(R.id.tvScanResult);
        scanFormat = findViewById(R.id.tvScanFormat);
        ScanOptions options = new ScanOptions();
        options.setPrompt("Scan a BarCode/QRCode");
        options.setOrientationLocked(false);
        options.setBeepEnabled(false);
        barcodeLauncher.launch(options);

        // IntentIntegrator integrator = new IntentIntegrator(this);
        // integrator.setPrompt("Scan a BarCode/QRCode");
        // integrator.setOrientationLocked(true);
        // integrator.initiateScan();
    }

    public void Backbtn(View v) {
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(i);
    }

    protected void onActivityResult(@Nullable ScanIntentResult intentResult) {
        if (intentResult != null) {
            String androidId = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ANDROID_ID);
            JSONObject myMsg = null;
            try {
                myMsg = new JSONObject("{\"deviceId\": \"" + androidId + "\", \"topic\": \"QRSCANResult\", \"text\": \"text\"}");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            JSONObject jsonObj = null;
            if (intentResult.getContents() == null) {
                try {
                    myMsg.put("text", "Scanning Cancelled by User");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String msg = myMsg.toString();

                Intent in = new Intent("com.ashley.ashley");
                Bundle extras = new Bundle();
                extras.putString("com.ashley.ashley.QRCODE", msg);
                in.putExtras(extras);
                sendBroadcast(in);
                Log.d("TAG", "QRCODE Scanning Cancelled");
                Toast.makeText(getBaseContext(), "Cancelled", Toast.LENGTH_LONG).show();
                finishAndRemoveTask();

            } else {
                scanFormat.setText(intentResult.getFormatName());
                scanResult.setText(intentResult.getContents());


                try {
                    jsonObj = new JSONObject("{\"Format\": \"" + intentResult.getFormatName() + "\", \"Contents\": \"" + intentResult.getContents() + "\"}");
                    myMsg.put("text", jsonObj);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String msg = myMsg.toString();

                Intent in = new Intent("com.ashley.ashley");
                Bundle extras = new Bundle();
                extras.putString("com.ashley.ashley.QRCODE", msg);
                in.putExtras(extras);
                sendBroadcast(in);
                Log.d("TAG", "QRCODE Transmitted");
                finishAndRemoveTask();

            }

        }
    }
}