package com.ashley.ashley;

import android.app.Application;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.util.Log;
import android.webkit.WebView;
import android.widget.Toast;

public class HelixApplication extends Application {
    private WebView mWebView;
    private boolean mWebViewInitialized;

    @Override
    public void onCreate() {
        super.onCreate();

        // Enables remote debugging of web pages hosted in WebView components.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if (0 != (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE))
            { WebView.setWebContentsDebuggingEnabled(true); }
        }

        mWebView = new WebView(this);
        mWebViewInitialized = false;
    }

    public WebView getWebView() { return mWebView; }
    public boolean isWebViewInitialized() { return mWebViewInitialized; }
    public void setWebViewInitialized(boolean initialized) {
        mWebViewInitialized = initialized;
    }
}
